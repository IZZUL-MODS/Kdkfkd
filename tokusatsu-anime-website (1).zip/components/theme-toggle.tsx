"use client"

import { Moon, Cloud } from "lucide-react"
import { useTheme } from "./theme-provider"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const isDark = theme === "dark"

  return (
    <div
      role="group"
      aria-label="Mode siang dan malam"
      className="relative flex items-center gap-1 rounded-full border border-border bg-card/60 p-1 backdrop-blur"
    >
      {/* sliding indicator */}
      <span
        aria-hidden
        className="absolute top-1 bottom-1 w-9 rounded-full bg-primary transition-all duration-300 ease-out"
        style={{ left: isDark ? "calc(100% - 2.5rem)" : "0.25rem" }}
      />
      <button
        type="button"
        onClick={() => setTheme("light")}
        aria-pressed={!isDark}
        aria-label="Mode siang (cerah)"
        title="Mode siang — website cerah"
        className={`relative z-10 flex h-8 w-9 items-center justify-center rounded-full transition-colors ${
          !isDark ? "text-primary-foreground" : "text-muted-foreground hover:text-foreground"
        }`}
      >
        <Cloud className="h-4 w-4" />
      </button>
      <button
        type="button"
        onClick={() => setTheme("dark")}
        aria-pressed={isDark}
        aria-label="Mode malam (gelap gulita)"
        title="Mode malam — website gelap gulita"
        className={`relative z-10 flex h-8 w-9 items-center justify-center rounded-full transition-colors ${
          isDark ? "text-primary-foreground" : "text-muted-foreground hover:text-foreground"
        }`}
      >
        <Moon className="h-4 w-4" />
      </button>
    </div>
  )
}
