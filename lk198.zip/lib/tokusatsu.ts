// Data layer for tokusatsuindo.com
// We proxy the public WordPress REST API and the theme's player AJAX endpoint
// so the browser never has to touch the original (ad-heavy) site directly.

import { resolveDriveDownload } from "@/lib/drive"

export const SOURCE_ORIGIN = "https://www.tokusatsuindo.com"
const REST = `${SOURCE_ORIGIN}/wp-json/wp/v2`
const AJAX = `${SOURCE_ORIGIN}/wp-admin/admin-ajax.php`

export type Film = {
  id: number
  title: string
  slug: string
  image: string | null
  date: string
  views: number | null
  genres: string[]
}

export type Server = {
  name: string
  url: string
  host: string
}

// A playable source for an episode. `streamUrl`, when present, is the upstream
// login-free, ad-free MP4 (the site's own /stream.php proxy) that we re-proxy
// through /api/stream so the browser plays it in a native <video> element with
// seeking. `embedUrl` is the iframe fallback used when there is no direct
// stream, or if the direct stream fails to play at runtime.
export type VideoSource = {
  name: string
  // Upstream direct MP4 URL (player.tokusatsuindo.com/stream.php?t=...).
  // Empty string for iframe-only sources (e.g. gdplayer).
  streamUrl: string
  // Iframe fallback that plays without a Google login (site player / gdplayer).
  embedUrl: string
}

export type Category = {
  id: number
  name: string
  count: number
}

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

// Decode the most common HTML entities WordPress returns in titles.
export function decodeEntities(input: string): string {
  if (!input) return ""
  return input
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCharCode(Number.parseInt(code, 16)))
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&hellip;/g, "…")
    .replace(/&#8217;|&rsquo;/g, "'")
    .replace(/&#8216;|&lsquo;/g, "'")
    .replace(/&#8211;|&ndash;/g, "–")
    .replace(/&#8212;|&mdash;/g, "—")
    .trim()
}

type WpPost = {
  id: number
  slug: string
  date: string
  title: { rendered: string }
  views?: number
  _embedded?: {
    "wp:featuredmedia"?: Array<{ source_url?: string }>
    "wp:term"?: Array<Array<{ name: string; taxonomy: string }>>
  }
}

function mapPost(p: WpPost): Film {
  const media = p._embedded?.["wp:featuredmedia"]?.[0]?.source_url ?? null
  const terms = p._embedded?.["wp:term"]?.flat() ?? []
  const genres = terms
    .filter((t) => t.taxonomy === "category")
    .map((t) => decodeEntities(t.name))
    .filter((name) => name.toLowerCase() !== "sub indonesia")
    .slice(0, 3)
  return {
    id: p.id,
    slug: p.slug,
    date: p.date,
    title: decodeEntities(p.title?.rendered ?? ""),
    image: media,
    views: typeof p.views === "number" ? p.views : null,
    genres,
  }
}

export async function fetchFilms(opts: {
  search?: string
  page?: number
  perPage?: number
  category?: number
}): Promise<{ films: Film[]; totalPages: number }> {
  const params = new URLSearchParams()
  params.set("per_page", String(opts.perPage ?? 24))
  params.set("page", String(opts.page ?? 1))
  params.set("_embed", "wp:featuredmedia,wp:term")
  params.set(
    "_fields",
    "id,slug,date,title,views,_links,_embedded",
  )
  if (opts.search) params.set("search", opts.search)
  if (opts.category) params.set("categories", String(opts.category))

  const res = await fetch(`${REST}/posts?${params.toString()}`, {
    headers: { "User-Agent": UA, Accept: "application/json" },
    next: { revalidate: 300 },
  })

  if (!res.ok) {
    return { films: [], totalPages: 0 }
  }

  const totalPages = Number(res.headers.get("x-wp-totalpages") ?? "1")
  const data = (await res.json()) as WpPost[]
  return { films: data.map(mapPost), totalPages }
}

export async function fetchCategories(): Promise<Category[]> {
  const res = await fetch(
    `${REST}/categories?per_page=12&orderby=count&order=desc&_fields=id,name,count`,
    { headers: { "User-Agent": UA }, next: { revalidate: 3600 } },
  )
  if (!res.ok) return []
  const data = (await res.json()) as Array<{ id: number; name: string; count: number }>
  return data
    .map((c) => ({ id: c.id, name: decodeEntities(c.name), count: c.count }))
    .filter((c) => c.name.toLowerCase() !== "sub indonesia")
}

const HOST_LABELS: Record<string, string> = {
  "player.tokusatsuindo.com": "Server Utama (Tanpa Iklan)",
  "gdplayer.to": "Google Drive Player",
}

function labelFor(host: string, index: number): string {
  return HOST_LABELS[host] ?? `Server ${index + 1}`
}

// Calls the muvipro theme AJAX endpoint to retrieve the real embedded
// player iframe(s) for a post, then extracts the clean iframe src URLs.
export async function fetchServers(postId: number): Promise<Server[]> {
  const tabs = ["p1", "p2", "p3"]
  const results = await Promise.all(
    tabs.map(async (tab) => {
      try {
        const res = await fetch(AJAX, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Referer: SOURCE_ORIGIN,
          },
          body: `action=muvipro_player_content&tab=${tab}&post_id=${postId}`,
          next: { revalidate: 600 },
        })
        if (!res.ok) return null
        return await res.text()
      } catch {
        return null
      }
    }),
  )

  const servers: Server[] = []
  const seen = new Set<string>()

  results.forEach((html) => {
    if (!html) return
    const match = html.match(/<iframe[^>]+src=["']([^"']+)["']/i)
    if (!match) return
    let url = match[1]
    if (url.startsWith("//")) url = `https:${url}`
    if (!/^https?:\/\//i.test(url)) return
    if (seen.has(url)) return
    seen.add(url)
    let host = ""
    try {
      host = new URL(url).hostname.replace(/^www\./, "")
    } catch {
      return
    }
    servers.push({ url, host, name: labelFor(host, servers.length) })
  })

  // Prefer the site's own ad-free player first.
  servers.sort((a, b) => {
    const score = (s: Server) => (s.host.includes("player.tokusatsuindo.com") ? 0 : 1)
    return score(a) - score(b)
  })

  return servers
}

// --- Direct stream resolution -------------------------------------------

type StreamMirror = { name: string; url: string }

// Decodes the Google Drive file id(s) baked into a player token. The token is
// `base64url(JSON).signature`; the JSON carries `file_id` (and mirror variants
// `file_id_1` / `file_id_2`). These ids let us build an authenticated HD
// download fallback for files the stream.php proxy can't serve.
function fileIdsFromToken(token: string): string[] {
  try {
    const payload = token.split(".")[0]
    const b64 = payload.replace(/-/g, "+").replace(/_/g, "/")
    const json = Buffer.from(b64, "base64").toString("utf8")
    const data = JSON.parse(json) as Record<string, unknown>
    const ids = [data.file_id, data.file_id_1, data.file_id_2]
      .filter((v): v is string => typeof v === "string" && v.length > 0)
    return Array.from(new Set(ids))
  } catch {
    return []
  }
}

// Follows the site player chain (outer `/x/?t=` page -> inner `/p/?t=` page)
// and extracts the `streamSources` array baked into the inner page. Each entry
// is a `/stream.php?t=<token>` URL: a server-side proxy that streams the Google
// Drive file directly, with NO Google login wall and NO ads, and which works
// for HD files too. These are the URLs we re-proxy through /api/stream.
type ExtractResult = { mirrors: StreamMirror[]; fileIds: string[] }

async function extractStreamMirrors(playerUrl: string): Promise<ExtractResult> {
  const empty: ExtractResult = { mirrors: [], fileIds: [] }
  try {
    const url = new URL(playerUrl)
    let innerToken = ""
    let referer = SOURCE_ORIGIN

    if (url.pathname.includes("/p/")) {
      innerToken = url.searchParams.get("t") ?? ""
    } else {
      // Outer /x/ page -> find the inner /p/?t= token.
      const res = await fetch(playerUrl, {
        headers: { "User-Agent": UA, Referer: SOURCE_ORIGIN },
        next: { revalidate: 600 },
      })
      if (!res.ok) return empty
      const html = await res.text()
      const inner = html.match(/\/p\/\?t=([A-Za-z0-9_.\-]+)/)
      if (!inner) return empty
      innerToken = inner[1]
      referer = playerUrl
    }

    if (!innerToken) return empty

    const fileIds = fileIdsFromToken(innerToken)

    const innerUrl = `https://player.tokusatsuindo.com/p/?t=${innerToken}`
    const res2 = await fetch(innerUrl, {
      headers: { "User-Agent": UA, Referer: referer },
      next: { revalidate: 600 },
    })
    if (!res2.ok) return { mirrors: [], fileIds }
    const page = await res2.text()

    const mirrors: StreamMirror[] = []
    const seen = new Set<string>()
    const re =
      /"label"\s*:\s*"([^"]*)"\s*,\s*"url"\s*:\s*"(https:\\?\/\\?\/player\.tokusatsuindo\.com\\?\/stream\.php\?t=[^"]+)"/g
    let m: RegExpExecArray | null
    while ((m = re.exec(page))) {
      const cleanUrl = m[2].replace(/\\\//g, "/")
      if (seen.has(cleanUrl)) continue
      seen.add(cleanUrl)
      mirrors.push({ name: m[1] || `Server ${mirrors.length + 1}`, url: cleanUrl })
    }
    return { mirrors, fileIds }
  } catch {
    return empty
  }
}

// Builds the `/api/stream` proxy URL for an upstream stream.php mirror.
function proxyUrl(streamUrl: string): string {
  return `/api/stream?u=${encodeURIComponent(streamUrl)}`
}

// Builds the `/api/stream` proxy URL for an authenticated HD direct-download of
// a Drive file id (used as the quota-limited HD fallback).
function downloadProxyUrl(fileId: string): string {
  return `/api/stream?fid=${encodeURIComponent(fileId)}`
}

// Resolves a post into a list of playable sources, in priority order:
//  1. Direct, login-free, ad-free MP4 streams from the site's own /stream.php
//     proxy (works for SD *and* HD). Played in a native <video> element via our
//     /api/stream re-proxy, so there is NO Google login wall and NO ads.
//  2. The site player / gdplayer iframes as a fallback — these also play
//     without a Google login (gdplayer streams the file itself), so the episode
//     is always watchable even if stream.php extraction fails.
//
// Note: we deliberately do NOT use the Google Drive `/preview` iframe anymore —
// that embed is exactly what triggered the "sign in to your Google account"
// wall for files that aren't publicly shared.
export async function fetchSources(postId: number): Promise<VideoSource[]> {
  const servers = await fetchServers(postId)
  if (servers.length === 0) return []

  const sources: VideoSource[] = []
  const seenStreams = new Set<string>()
  const iframeFallbacks: VideoSource[] = []

  // Extract stream.php mirrors (and Drive file ids) from every site player.
  const playerServers = servers.filter((s) => s.host.includes("player.tokusatsuindo.com"))
  const extracted = await Promise.all(playerServers.map((s) => extractStreamMirrors(s.url)))

  // Collect a representative embed url per unique Drive file id (used as the
  // iframe fallback for that file's HD source).
  const fileIdEmbeds = new Map<string, string>()

  let serverIndex = 0
  playerServers.forEach((server, i) => {
    for (const mirror of extracted[i].mirrors) {
      if (seenStreams.has(mirror.url)) continue
      seenStreams.add(mirror.url)
      serverIndex += 1
      sources.push({
        name: `Server ${serverIndex} (Tanpa Iklan)`,
        streamUrl: mirror.url,
        // The site player iframe for the same file, used only if the direct
        // proxy stream fails to play at runtime.
        embedUrl: server.url,
      })
    }
    for (const fileId of extracted[i].fileIds) {
      if (!fileIdEmbeds.has(fileId)) fileIdEmbeds.set(fileId, server.url)
    }
    // Keep the player iframe itself as a fallback even when extraction succeeds.
    iframeFallbacks.push({ name: "Server Cadangan", streamUrl: "", embedUrl: server.url })
  })

  // Authenticated HD direct-download fallback per unique Drive file id. This is
  // what lets quota-limited HD files still play through the ad-free proxy when
  // stream.php can't serve them. We pre-resolve each id so files that genuinely
  // can't be downloaded (owner disabled it) don't show a dead "HD" tab.
  const fileIds = [...fileIdEmbeds.keys()]
  const resolved = await Promise.all(fileIds.map((id) => resolveDriveDownload(id)))
  fileIds.forEach((fileId, i) => {
    if (!resolved[i].url) return
    sources.push({
      name: "Server HD (Tanpa Iklan)",
      streamUrl: downloadProxyUrl(fileId),
      embedUrl: fileIdEmbeds.get(fileId) ?? servers[0].url,
    })
  })

  // Non-player servers (e.g. gdplayer) can only be embedded as iframes. They
  // still play without a Google login, so they make a reliable last resort.
  for (const server of servers) {
    if (server.host.includes("player.tokusatsuindo.com")) continue
    iframeFallbacks.push({ name: server.name || "Server Cadangan", streamUrl: "", embedUrl: server.url })
  }

  // Append iframe fallbacks (deduped) after the direct streams.
  const seenEmbeds = new Set(sources.map((s) => s.embedUrl))
  for (const fb of iframeFallbacks) {
    if (seenEmbeds.has(fb.embedUrl)) continue
    seenEmbeds.add(fb.embedUrl)
    sources.push(fb)
  }

  return sources
}

export { proxyUrl as streamProxyUrl }

export async function fetchFilm(id: number): Promise<Film | null> {
  const res = await fetch(
    `${REST}/posts/${id}?_embed=wp:featuredmedia,wp:term&_fields=id,slug,date,title,views,_links,_embedded`,
    { headers: { "User-Agent": UA }, next: { revalidate: 300 } },
  )
  if (!res.ok) return null
  const data = (await res.json()) as WpPost
  return mapPost(data)
}
