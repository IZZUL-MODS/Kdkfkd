import Link from "next/link"
import { Play, Eye } from "lucide-react"
import type { Film } from "@/lib/tokusatsu"

function formatViews(n: number | null): string | null {
  if (n == null) return null
  if (n >= 1000) return `${(n / 1000).toFixed(1).replace(/\.0$/, "")}rb`
  return String(n)
}

export function FilmCard({ film }: { film: Film }) {
  const views = formatViews(film.views)
  return (
    <Link
      href={`/watch/${film.id}`}
      className="card-sheen group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-all duration-300 hover:-translate-y-1.5 hover:border-primary/60 hover:shadow-xl hover:shadow-primary/20"
    >
      <div className="relative aspect-[2/3] overflow-hidden bg-muted">
        {film.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={film.image || "/placeholder.svg"}
            alt={film.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center font-condensed text-3xl text-muted-foreground">
            TOKU
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />

        {/* Play overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg ring-4 ring-primary/30">
            <Play className="h-6 w-6 translate-x-0.5 fill-current" />
          </span>
        </div>

        {views && (
          <span className="absolute right-2 top-2 inline-flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5 text-[0.65rem] font-medium text-white backdrop-blur">
            <Eye className="h-3 w-3" />
            {views}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2 p-3">
        <h3 className="line-clamp-2 text-sm font-semibold leading-snug text-card-foreground transition-colors group-hover:text-primary">
          {film.title}
        </h3>
        {film.genres.length > 0 && (
          <div className="mt-auto flex flex-wrap gap-1">
            {film.genres.map((g) => (
              <span
                key={g}
                className="rounded-full bg-secondary px-2 py-0.5 text-[0.6rem] font-medium uppercase tracking-wide text-secondary-foreground"
              >
                {g}
              </span>
            ))}
          </div>
        )}
      </div>
    </Link>
  )
}
