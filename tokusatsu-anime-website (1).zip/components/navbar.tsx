"use client"

import Link from "next/link"
import { Atom } from "lucide-react"
import { useEffect, useState } from "react"
import { ThemeToggle } from "./theme-toggle"

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "border-b border-border bg-background/80 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        {/* Left: logo + brand */}
        <Link href="/" className="group flex items-center gap-3" aria-label="Tokusatsu beranda">
          <span className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg transition-transform duration-300 group-hover:scale-105 group-hover:rotate-6">
            <Atom className="h-6 w-6 fx-float" />
            <span className="absolute inset-0 rounded-xl ring-2 ring-primary/40" />
          </span>
          <span className="flex flex-col leading-none">
            <span className="fx-gradient font-accent text-xl tracking-wide sm:text-2xl">
              Tokusatsu
            </span>
            <span className="mt-1 font-condensed text-[0.7rem] tracking-[0.35em] text-muted-foreground">
              BY IZZUL
            </span>
          </span>
        </Link>

        {/* Right: day / night toggle */}
        <ThemeToggle />
      </nav>
    </header>
  )
}
