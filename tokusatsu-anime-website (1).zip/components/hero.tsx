"use client"

import { Sparkles, ShieldCheck, ChevronDown } from "lucide-react"

const TAGLINE = "HENSHIN. WATCH. REPEAT."

export function Hero() {
  return (
    <section className="relative flex min-h-[78vh] flex-col items-center justify-center overflow-hidden px-4 pt-16 pb-10 text-center">
      <div
        className="fx-float mb-6 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-card/60 px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur"
        role="note"
      >
        <ShieldCheck className="h-4 w-4 text-primary" />
        Streaming tanpa iklan • langsung dari sumber
      </div>

      {/* Brand display title — Orbitron with neon glow */}
      <h1 className="font-display text-5xl font-black uppercase leading-none tracking-tight sm:text-7xl md:text-8xl">
        <span className="fx-neon block text-foreground">Dunia</span>
        <span className="fx-gradient block">Tokusatsu</span>
      </h1>

      {/* Tagline — Bebas Neue, letter-by-letter rise */}
      <p
        className="fx-rise mt-6 font-condensed text-2xl tracking-[0.3em] text-muted-foreground sm:text-3xl"
        aria-label={TAGLINE}
      >
        {TAGLINE.split("").map((ch, i) => (
          <span key={i} style={{ animationDelay: `${0.4 + i * 0.04}s` }}>
            {ch === " " ? "\u00A0" : ch}
          </span>
        ))}
      </p>

      <p className="mt-6 max-w-xl text-pretty text-sm leading-relaxed text-muted-foreground sm:text-base">
        Nonton Kamen Rider, Super Sentai, Ultraman, dan ratusan judul tokusatsu
        sub Indonesia. Cari judul favoritmu lalu tonton langsung dari sini.
      </p>

      <a
        href="#jelajah"
        className="group mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 font-accent text-sm tracking-wide text-primary-foreground shadow-lg transition-transform hover:scale-105"
      >
        <Sparkles className="h-4 w-4" />
        Mulai Jelajah
      </a>

      <a
        href="#jelajah"
        aria-hidden
        className="mt-12 animate-bounce text-muted-foreground"
      >
        <ChevronDown className="h-6 w-6" />
      </a>
    </section>
  )
}
