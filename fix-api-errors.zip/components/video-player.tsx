"use client"

import { useState } from "react"
import { Server, MonitorPlay, ExternalLink, AlertTriangle } from "lucide-react"
import type { Server as VideoServer } from "@/lib/tokusatsu"

// Hosts that proxy Google Drive files. These can hit Google's per-file
// "too many viewers" quota and show a login wall inside the iframe.
function isRateLimitedHost(host: string): boolean {
  return host.includes("gdplayer") || host.includes("drive.google")
}

export function VideoPlayer({ servers }: { servers: VideoServer[] }) {
  const [active, setActive] = useState(0)

  if (servers.length === 0) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl border border-border bg-card text-center text-muted-foreground">
        <MonitorPlay className="h-10 w-10" />
        <p className="font-condensed text-2xl tracking-widest">VIDEO BELUM TERSEDIA</p>
        <p className="max-w-sm text-sm">
          Sumber sedang menyiapkan episode ini. Coba lagi nanti.
        </p>
      </div>
    )
  }

  const current = servers[Math.min(active, servers.length - 1)]
  const rateLimited = isRateLimitedHost(current.host)
  const hasMainServer = servers.some((s) => !isRateLimitedHost(s.host))

  return (
    <div className="flex flex-col gap-4">
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-border bg-black shadow-2xl shadow-primary/20 ring-1 ring-primary/20">
        <iframe
          key={current.url}
          src={current.url}
          title={current.name}
          className="h-full w-full"
          allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
          allowFullScreen
          referrerPolicy="no-referrer"
        />
      </div>

      {rateLimited && (
        <div className="flex flex-col gap-3 rounded-xl border border-primary/30 bg-primary/5 p-4 text-sm sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-2.5 text-muted-foreground">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <p className="leading-relaxed">
              {hasMainServer ? (
                <>
                  Server Google Drive bisa meminta login Google karena batas tontonan.{" "}
                  <button
                    type="button"
                    onClick={() => setActive(servers.findIndex((s) => !isRateLimitedHost(s.host)))}
                    className="font-semibold text-primary underline-offset-2 hover:underline"
                  >
                    Beralih ke Server Utama
                  </button>{" "}
                  yang tanpa login.
                </>
              ) : (
                "Server ini bisa meminta login Google karena batas tontonan. Coba buka langsung di tab baru."
              )}
            </p>
          </div>
          <a
            href={current.url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-full bg-primary px-4 py-1.5 text-xs font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            Buka di tab baru
          </a>
        </div>
      )}

      {servers.length > 1 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <Server className="h-4 w-4" />
            Pilih server:
          </span>
          {servers.map((s, i) => (
            <button
              key={s.url}
              type="button"
              onClick={() => setActive(i)}
              className={`rounded-full px-4 py-1.5 text-xs font-medium transition-colors ${
                i === active
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-primary/20"
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
