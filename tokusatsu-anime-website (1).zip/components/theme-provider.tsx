"use client"

import { createContext, useCallback, useContext, useEffect, useState } from "react"

type Theme = "light" | "dark"

type ThemeContextValue = {
  theme: Theme
  setTheme: (t: Theme) => void
  toggle: () => void
}

const ThemeContext = createContext<ThemeContextValue | null>(null)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("dark")

  // Sync state with whatever the inline pre-hydration script applied.
  useEffect(() => {
    const stored = (localStorage.getItem("toku-theme") as Theme | null) ?? "dark"
    setThemeState(stored)
  }, [])

  const applyTheme = useCallback((t: Theme) => {
    const root = document.documentElement
    root.classList.remove("light", "dark")
    root.classList.add(t)
    try {
      localStorage.setItem("toku-theme", t)
    } catch {
      // ignore storage errors
    }
  }, [])

  const setTheme = useCallback(
    (t: Theme) => {
      setThemeState(t)
      applyTheme(t)
    },
    [applyTheme],
  )

  const toggle = useCallback(() => {
    setTheme(theme === "dark" ? "light" : "dark")
  }, [theme, setTheme])

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggle }}>{children}</ThemeContext.Provider>
  )
}

export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider")
  return ctx
}
