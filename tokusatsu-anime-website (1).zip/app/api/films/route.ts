import { NextResponse } from "next/server"
import { fetchFilms } from "@/lib/tokusatsu"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const search = searchParams.get("search") ?? undefined
  const page = Number(searchParams.get("page") ?? "1")
  const categoryParam = searchParams.get("category")
  const category = categoryParam ? Number(categoryParam) : undefined

  const data = await fetchFilms({
    search: search || undefined,
    page: Number.isFinite(page) && page > 0 ? page : 1,
    category,
    perPage: 24,
  })

  return NextResponse.json(data, {
    headers: {
      "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600",
    },
  })
}
