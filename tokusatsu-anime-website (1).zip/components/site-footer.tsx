import { Atom } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="mt-20 border-t border-border bg-card/40">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-3 px-4 py-10 text-center sm:px-6">
        <div className="flex items-center gap-2">
          <Atom className="h-5 w-5 text-primary" />
          <span className="fx-gradient font-accent text-lg tracking-wide">Tokusatsu</span>
        </div>
        <p className="max-w-md text-xs leading-relaxed text-muted-foreground">
          Data film bersumber dari tokusatsuindo.com. Situs ini hanya menampilkan
          ulang katalog dan pemutar resmi tanpa iklan tambahan.
        </p>
        <p className="font-condensed text-sm tracking-[0.3em] text-muted-foreground">
          BY IZZUL
        </p>
      </div>
    </footer>
  )
}
