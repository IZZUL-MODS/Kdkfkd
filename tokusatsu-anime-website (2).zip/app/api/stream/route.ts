import type { NextRequest } from "next/server"
import { getStreamUrl, DRIVE_UA } from "@/lib/drive"

// Streams an episode through our own server, with no ads and no Google login.
//
// Primary path: ?u=<stream.php url>. The source site (player.tokusatsuindo.com)
// exposes a server-side proxy at /stream.php?t=<token> that already serves a
// clean, seekable, login-free MP4 for the Google Drive file — including HD
// files that Google's get_video_info cannot turn into a progressive stream. We
// simply re-proxy those bytes (forwarding Range headers so seeking works) and
// strip third-party referrers/ads.
//
// Fallback path: ?fid=<fileId>&itag=<itag>. Resolves a Drive file id to a
// direct googlevideo URL via get_video_info. Kept for compatibility.

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

// Hosts we are willing to proxy via ?u=. Prevents this route from being abused
// as an open proxy.
const ALLOWED_STREAM_HOSTS = new Set([
  "player.tokusatsuindo.com",
])

async function resolveTarget(
  req: NextRequest,
): Promise<{ url: string; referer: string } | { error: string; status: number }> {
  const { searchParams } = new URL(req.url)
  const u = searchParams.get("u")

  if (u) {
    let target: URL
    try {
      target = new URL(u)
    } catch {
      return { error: "Bad url", status: 400 }
    }
    if (!ALLOWED_STREAM_HOSTS.has(target.hostname)) {
      return { error: "Host not allowed", status: 403 }
    }
    return { url: target.toString(), referer: `${target.protocol}//${target.hostname}/` }
  }

  const fid = searchParams.get("fid")
  if (!fid) return { error: "Missing source", status: 400 }
  const itagParam = searchParams.get("itag")
  const itag = itagParam ? Number(itagParam) : undefined
  const streamUrl = await getStreamUrl(fid, Number.isFinite(itag) ? itag : undefined)
  if (!streamUrl) return { error: "Stream not available", status: 404 }
  return { url: streamUrl, referer: "https://drive.google.com/" }
}

export async function GET(req: NextRequest) {
  const resolved = await resolveTarget(req)
  if ("error" in resolved) {
    return new Response(resolved.error, { status: resolved.status })
  }

  const range = req.headers.get("range")
  const upstreamHeaders: Record<string, string> = {
    "User-Agent": DRIVE_UA,
    Referer: resolved.referer,
  }
  if (range) upstreamHeaders["Range"] = range

  let upstream: Response
  try {
    upstream = await fetch(resolved.url, { headers: upstreamHeaders, cache: "no-store" })
  } catch {
    return new Response("Upstream fetch failed", { status: 502 })
  }

  if (!upstream.ok && upstream.status !== 206) {
    return new Response("Upstream error", { status: 502 })
  }

  const headers = new Headers()
  const passthrough = [
    "content-type",
    "content-length",
    "content-range",
    "accept-ranges",
    "cache-control",
    "expires",
    "last-modified",
  ]
  for (const key of passthrough) {
    const value = upstream.headers.get(key)
    if (value) headers.set(key, value)
  }
  if (!headers.has("content-type")) headers.set("content-type", "video/mp4")
  if (!headers.has("accept-ranges")) headers.set("accept-ranges", "bytes")

  return new Response(upstream.body, {
    status: upstream.status,
    headers,
  })
}
