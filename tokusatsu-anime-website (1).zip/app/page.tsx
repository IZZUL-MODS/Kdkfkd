import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { FilmBrowser } from "@/components/film-browser"
import { SiteFooter } from "@/components/site-footer"
import { fetchFilms, fetchCategories } from "@/lib/tokusatsu"

export const revalidate = 300

export default async function HomePage() {
  const [initial, categories] = await Promise.all([
    fetchFilms({ page: 1, perPage: 24 }),
    fetchCategories(),
  ])

  return (
    <>
      <div className="aura" aria-hidden />
      <Navbar />
      <main>
        <Hero />
        <FilmBrowser initial={initial} categories={categories} />
      </main>
      <SiteFooter />
    </>
  )
}
