"use client"

import { useMemo, useRef, useState } from "react"
import { Server, MonitorPlay } from "lucide-react"
import type { VideoSource } from "@/lib/tokusatsu"
import { streamProxyUrl } from "@/lib/tokusatsu"

export function VideoPlayer({ sources }: { sources: VideoSource[] }) {
  // Every source is selectable. Direct, login-free, ad-free MP4 streams (the
  // site's own /stream.php proxy) come first and play in a native <video>
  // element with seeking. Iframe fallbacks (site player / gdplayer) play HD
  // files without a Google login if a direct stream ever fails.
  const allSources = useMemo(
    () => sources.filter((s) => s.streamUrl || s.embedUrl),
    [sources],
  )

  const [activeSource, setActiveSource] = useState(0)
  // Per-source flag: a direct proxy stream that failed to play falls back to its
  // own iframe instead of disappearing.
  const [failedDirect, setFailedDirect] = useState<Record<number, boolean>>({})
  const videoRef = useRef<HTMLVideoElement>(null)

  if (allSources.length === 0) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl border border-border bg-card text-center text-muted-foreground">
        <MonitorPlay className="h-10 w-10" />
        <p className="font-condensed text-2xl tracking-widest">VIDEO BELUM TERSEDIA</p>
        <p className="max-w-sm text-sm">Sumber sedang menyiapkan episode ini. Coba lagi nanti.</p>
      </div>
    )
  }

  const idx = Math.min(activeSource, allSources.length - 1)
  const source = allSources[idx]
  const hasDirect = !!source.streamUrl && !failedDirect[idx]
  // HD sources already carry a ready-to-play proxy path (/api/stream?fid=...);
  // stream.php mirrors carry an upstream URL that must be wrapped by the proxy.
  const playbackSrc = source.streamUrl.startsWith("/api/")
    ? source.streamUrl
    : streamProxyUrl(source.streamUrl)

  return (
    <div className="flex flex-col gap-4">
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-border bg-black shadow-2xl shadow-primary/20 ring-1 ring-primary/20">
        {hasDirect ? (
          <video
            ref={videoRef}
            key={playbackSrc}
            src={playbackSrc}
            className="h-full w-full bg-black"
            controls
            autoPlay
            playsInline
            controlsList="nodownload"
            onError={() => {
              // The direct proxy stream couldn't play (e.g. expired token). Fall
              // back to this source's iframe so the episode still plays instead
              // of going blank.
              setFailedDirect((prev) => ({ ...prev, [idx]: true }))
            }}
          />
        ) : (
          <iframe
            key={source.embedUrl}
            src={source.embedUrl}
            title="Video"
            className="h-full w-full"
            allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
            allowFullScreen
            referrerPolicy="no-referrer"
          />
        )}
      </div>

      {allSources.length > 1 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <Server className="h-4 w-4" />
            Server:
          </span>
          {allSources.map((s, i) => (
            <button
              key={`${s.name}-${i}`}
              type="button"
              onClick={() => setActiveSource(i)}
              className={`rounded-full px-4 py-1.5 text-xs font-medium transition-colors ${
                i === idx
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-primary/20"
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
