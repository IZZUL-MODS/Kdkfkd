import type { NextRequest } from "next/server"
import {
  resolveDriveDownload,
  driveCookieHeader,
  driveApiMediaUrl,
  DRIVE_UA,
} from "@/lib/drive"
import { resolveMirror } from "@/lib/tokusatsu"

// Streams an episode through our own server, with no ads and no Google login.
//
// Primary path: ?id=<postId>&i=<sourceIndex>. We resolve a FRESH stream.php
// token at request time (player.tokusatsuindo.com exposes a server-side proxy
// that already serves a clean, seekable, login-free MP4 — including HD files).
// Resolving here, instead of baking the token into the cached watch page, is
// what keeps playback alive: those tokens expire ~15 minutes after issuance, so
// a cached token routinely died mid-watch and fell back to the Drive quota wall
// ("tidak dapat memuat video / coba lagi / download"). If stream.php can't serve
// the file, we fall back to the official Google Drive API (?alt=media), which
// has its own high quota and never shows that interstitial.
//
// Legacy paths: ?u=<stream.php url> (re-proxy a known stream URL) and
// ?fid=<fileId> (authenticated HD direct-download fallback).

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

// Hosts we are willing to proxy via ?u=. Prevents this route from being abused
// as an open proxy.
const ALLOWED_STREAM_HOSTS = new Set(["player.tokusatsuindo.com"])

type Target = { url: string; referer: string; withCookie: boolean }

// Builds the ordered list of upstream candidates to try for a request. The
// proxy plays the first one that responds with streamable bytes, so each entry
// is a graceful fallback for the previous.
async function resolveTargets(
  req: NextRequest,
): Promise<{ targets: Target[] } | { error: string; status: number }> {
  const { searchParams } = new URL(req.url)

  // Primary: resolve a fresh stream.php mirror (and its Drive file id) for a
  // post + source index.
  const id = searchParams.get("id")
  if (id) {
    const postId = Number(id)
    const index = Number(searchParams.get("i") ?? "0")
    if (!Number.isFinite(postId) || postId <= 0) {
      return { error: "Bad id", status: 400 }
    }
    const { url, fileId } = await resolveMirror(
      postId,
      Number.isFinite(index) && index >= 0 ? index : 0,
    )
    const targets: Target[] = []
    if (url) {
      targets.push({
        url,
        referer: "https://player.tokusatsuindo.com/",
        withCookie: false,
      })
    }
    // Google Drive API fallback (needs GOOGLE_DRIVE_API_KEY). Works for any
    // file shared "anyone with the link" and bypasses the per-file viewer wall.
    if (fileId) {
      const apiUrl = driveApiMediaUrl(fileId)
      if (apiUrl) {
        targets.push({ url: apiUrl, referer: "https://drive.google.com/", withCookie: false })
      }
      // Last resort: authenticated direct-download (needs GOOGLE_DRIVE_COOKIE).
      const { url: dlUrl } = await resolveDriveDownload(fileId)
      if (dlUrl) {
        targets.push({ url: dlUrl, referer: "https://drive.google.com/", withCookie: true })
      }
    }
    if (targets.length === 0) return { error: "Stream not available", status: 404 }
    return { targets }
  }

  // Legacy: re-proxy a specific stream.php URL.
  const u = searchParams.get("u")
  if (u) {
    let target: URL
    try {
      target = new URL(u)
    } catch {
      return { error: "Bad url", status: 400 }
    }
    if (!ALLOWED_STREAM_HOSTS.has(target.hostname)) {
      return { error: "Host not allowed", status: 403 }
    }
    return {
      targets: [
        {
          url: target.toString(),
          referer: `${target.protocol}//${target.hostname}/`,
          withCookie: false,
        },
      ],
    }
  }

  // Legacy: authenticated HD direct-download for a Drive file id.
  const fid = searchParams.get("fid")
  if (fid) {
    const targets: Target[] = []
    const apiUrl = driveApiMediaUrl(fid)
    if (apiUrl) targets.push({ url: apiUrl, referer: "https://drive.google.com/", withCookie: false })
    const { url, reason } = await resolveDriveDownload(fid)
    if (url) targets.push({ url, referer: "https://drive.google.com/", withCookie: true })
    if (targets.length === 0) {
      return {
        error: reason === "quota" ? "Quota limit reached" : "Stream not available",
        status: reason === "quota" ? 451 : 404,
      }
    }
    return { targets }
  }

  return { error: "Missing source", status: 400 }
}

async function fetchUpstream(target: Target, range: string | null): Promise<Response | null> {
  const headers: Record<string, string> = {
    "User-Agent": DRIVE_UA,
    Referer: target.referer,
  }
  if (range) headers["Range"] = range
  if (target.withCookie) {
    const cookie = driveCookieHeader()
    if (cookie) headers["Cookie"] = cookie
  }
  try {
    const res = await fetch(target.url, { headers, cache: "no-store" })
    if (!res.ok && res.status !== 206) {
      // Drain the failed body so the connection can be reused.
      await res.body?.cancel()
      return null
    }
    return res
  } catch {
    return null
  }
}

export async function GET(req: NextRequest) {
  const resolved = await resolveTargets(req)
  if ("error" in resolved) {
    return new Response(resolved.error, { status: resolved.status })
  }

  const range = req.headers.get("range")
  let upstream: Response | null = null
  for (const target of resolved.targets) {
    upstream = await fetchUpstream(target, range)
    if (upstream) break
  }

  if (!upstream) {
    return new Response("Upstream error", { status: 502 })
  }

  const headers = new Headers()
  const passthrough = [
    "content-type",
    "content-length",
    "content-range",
    "accept-ranges",
    "cache-control",
    "expires",
    "last-modified",
  ]
  for (const key of passthrough) {
    const value = upstream.headers.get(key)
    if (value) headers.set(key, value)
  }
  if (!headers.has("content-type")) headers.set("content-type", "video/mp4")
  if (!headers.has("accept-ranges")) headers.set("accept-ranges", "bytes")

  return new Response(upstream.body, {
    status: upstream.status,
    headers,
  })
}
