// Resolves a Google Drive file into direct, ad-free, login-free MP4 stream URLs.
//
// Both "servers" on the source site ultimately embed a Google Drive `/preview`
// iframe. That iframe is what triggers the "login to your Google account" wall
// and the "error playing this video" message once a file hits Google's
// per-file viewer quota. Instead, we hit Drive's legacy `get_video_info`
// endpoint which returns transcoded progressive MP4 URLs (the `videoplayback`
// streams). Those URLs are locked to the requesting IP, so we proxy them
// through our own server (see app/api/stream/route.ts).

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

export type DriveStream = {
  itag: number
  // Human readable quality label, e.g. "720p".
  label: string
  // The resolved (IP-locked, time-limited) googlevideo URL. Never sent to the
  // browser — only used server-side by the stream proxy.
  url: string
}

type CacheEntry = {
  streams: DriveStream[]
  expires: number
}

// In-memory cache of resolved streams keyed by file id. The googlevideo URLs
// are time-limited, so we keep them only briefly.
const cache = new Map<string, CacheEntry>()
const CACHE_TTL_MS = 4 * 60 * 1000

function labelForHeight(height: number): string {
  if (height >= 2160) return "4K"
  if (height >= 1440) return "1440p"
  if (height >= 1080) return "1080p"
  if (height >= 720) return "720p"
  if (height >= 480) return "480p"
  if (height >= 360) return "360p"
  if (height >= 240) return "240p"
  return `${height}p`
}

// itag → fallback height when fmt_list doesn't carry a resolution.
const ITAG_HEIGHT: Record<number, number> = {
  37: 1080,
  46: 1080,
  22: 720,
  45: 720,
  59: 480,
  44: 480,
  35: 480,
  18: 360,
  43: 360,
  34: 360,
  36: 240,
  17: 144,
  5: 240,
}

export async function resolveDriveStreams(fileId: string): Promise<DriveStream[]> {
  const cached = cache.get(fileId)
  if (cached && cached.expires > Date.now()) {
    return cached.streams
  }

  const res = await fetch(`https://drive.google.com/get_video_info?docid=${fileId}`, {
    headers: { "User-Agent": UA, Referer: "https://drive.google.com/" },
    cache: "no-store",
  })
  if (!res.ok) return []

  const body = await res.text()
  const params = new URLSearchParams(body)

  if (params.get("status") !== "ok") {
    return []
  }

  // fmt_list maps itag -> resolution, e.g. "22/1280x720/...,18/640x360/...".
  const heightByItag = new Map<number, number>()
  const fmtList = params.get("fmt_list") ?? ""
  for (const entry of fmtList.split(",")) {
    const [itagStr, res2] = entry.split("/")
    const itag = Number(itagStr)
    const height = Number((res2 ?? "").split("x")[1])
    if (Number.isFinite(itag) && Number.isFinite(height)) {
      heightByItag.set(itag, height)
    }
  }

  // fmt_stream_map maps itag -> url, e.g. "22|https://...,18|https://...".
  const streamMap = params.get("fmt_stream_map") ?? ""
  const streams: DriveStream[] = []
  for (const entry of streamMap.split(",")) {
    const sep = entry.indexOf("|")
    if (sep === -1) continue
    const itag = Number(entry.slice(0, sep))
    const url = entry.slice(sep + 1)
    if (!Number.isFinite(itag) || !/^https?:\/\//.test(url)) continue
    const height = heightByItag.get(itag) ?? ITAG_HEIGHT[itag] ?? 0
    streams.push({ itag, label: labelForHeight(height), url })
  }

  // Highest quality first.
  streams.sort((a, b) => {
    const ha = heightByItag.get(a.itag) ?? ITAG_HEIGHT[a.itag] ?? 0
    const hb = heightByItag.get(b.itag) ?? ITAG_HEIGHT[b.itag] ?? 0
    return hb - ha
  })

  if (streams.length > 0) {
    cache.set(fileId, { streams, expires: Date.now() + CACHE_TTL_MS })
  }
  return streams
}

// Returns the resolved googlevideo URL for a specific file + itag (or the best
// available quality if no itag is given). Used by the stream proxy.
export async function getStreamUrl(fileId: string, itag?: number): Promise<string | null> {
  const streams = await resolveDriveStreams(fileId)
  if (streams.length === 0) return null
  if (itag != null) {
    const match = streams.find((s) => s.itag === itag)
    if (match) return match.url
  }
  return streams[0].url
}

export { UA as DRIVE_UA }
