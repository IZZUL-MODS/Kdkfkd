import { resolveDriveStreams } from "@/lib/drive"

// Data layer for tokusatsuindo.com
// We proxy the public WordPress REST API and the theme's player AJAX endpoint
// so the browser never has to touch the original (ad-heavy) site directly.

export const SOURCE_ORIGIN = "https://www.tokusatsuindo.com"
const REST = `${SOURCE_ORIGIN}/wp-json/wp/v2`
const AJAX = `${SOURCE_ORIGIN}/wp-admin/admin-ajax.php`

export type Film = {
  id: number
  title: string
  slug: string
  image: string | null
  date: string
  views: number | null
  genres: string[]
}

export type Server = {
  name: string
  url: string
  host: string
}

// A playable source resolved down to a single Google Drive file, with its
// available qualities. The player streams these through our own proxy
// (/api/stream) so there is no Google login wall, no quota error, and no ads.
export type StreamQuality = {
  itag: number
  label: string
}

export type VideoSource = {
  name: string
  // The resolved Google Drive file id, when we have one (empty for sources we
  // can only embed, e.g. gdplayer).
  fileId: string
  qualities: StreamQuality[]
  // Iframe fallback used when no direct stream is available (or the proxy
  // stream fails to play). Prefers the site's own ad-free player; can be the
  // Drive /preview page or gdplayer as a last resort.
  embedUrl: string
}

export type Category = {
  id: number
  name: string
  count: number
}

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

// Decode the most common HTML entities WordPress returns in titles.
export function decodeEntities(input: string): string {
  if (!input) return ""
  return input
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCharCode(Number.parseInt(code, 16)))
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&hellip;/g, "…")
    .replace(/&#8217;|&rsquo;/g, "'")
    .replace(/&#8216;|&lsquo;/g, "'")
    .replace(/&#8211;|&ndash;/g, "–")
    .replace(/&#8212;|&mdash;/g, "—")
    .trim()
}

type WpPost = {
  id: number
  slug: string
  date: string
  title: { rendered: string }
  views?: number
  _embedded?: {
    "wp:featuredmedia"?: Array<{ source_url?: string }>
    "wp:term"?: Array<Array<{ name: string; taxonomy: string }>>
  }
}

function mapPost(p: WpPost): Film {
  const media = p._embedded?.["wp:featuredmedia"]?.[0]?.source_url ?? null
  const terms = p._embedded?.["wp:term"]?.flat() ?? []
  const genres = terms
    .filter((t) => t.taxonomy === "category")
    .map((t) => decodeEntities(t.name))
    .filter((name) => name.toLowerCase() !== "sub indonesia")
    .slice(0, 3)
  return {
    id: p.id,
    slug: p.slug,
    date: p.date,
    title: decodeEntities(p.title?.rendered ?? ""),
    image: media,
    views: typeof p.views === "number" ? p.views : null,
    genres,
  }
}

export async function fetchFilms(opts: {
  search?: string
  page?: number
  perPage?: number
  category?: number
}): Promise<{ films: Film[]; totalPages: number }> {
  const params = new URLSearchParams()
  params.set("per_page", String(opts.perPage ?? 24))
  params.set("page", String(opts.page ?? 1))
  params.set("_embed", "wp:featuredmedia,wp:term")
  params.set(
    "_fields",
    "id,slug,date,title,views,_links,_embedded",
  )
  if (opts.search) params.set("search", opts.search)
  if (opts.category) params.set("categories", String(opts.category))

  const res = await fetch(`${REST}/posts?${params.toString()}`, {
    headers: { "User-Agent": UA, Accept: "application/json" },
    next: { revalidate: 300 },
  })

  if (!res.ok) {
    return { films: [], totalPages: 0 }
  }

  const totalPages = Number(res.headers.get("x-wp-totalpages") ?? "1")
  const data = (await res.json()) as WpPost[]
  return { films: data.map(mapPost), totalPages }
}

export async function fetchCategories(): Promise<Category[]> {
  const res = await fetch(
    `${REST}/categories?per_page=12&orderby=count&order=desc&_fields=id,name,count`,
    { headers: { "User-Agent": UA }, next: { revalidate: 3600 } },
  )
  if (!res.ok) return []
  const data = (await res.json()) as Array<{ id: number; name: string; count: number }>
  return data
    .map((c) => ({ id: c.id, name: decodeEntities(c.name), count: c.count }))
    .filter((c) => c.name.toLowerCase() !== "sub indonesia")
}

const HOST_LABELS: Record<string, string> = {
  "player.tokusatsuindo.com": "Server Utama (Tanpa Iklan)",
  "gdplayer.to": "Google Drive Player",
}

function labelFor(host: string, index: number): string {
  return HOST_LABELS[host] ?? `Server ${index + 1}`
}

// Calls the muvipro theme AJAX endpoint to retrieve the real embedded
// player iframe(s) for a post, then extracts the clean iframe src URLs.
export async function fetchServers(postId: number): Promise<Server[]> {
  const tabs = ["p1", "p2", "p3"]
  const results = await Promise.all(
    tabs.map(async (tab) => {
      try {
        const res = await fetch(AJAX, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Referer: SOURCE_ORIGIN,
          },
          body: `action=muvipro_player_content&tab=${tab}&post_id=${postId}`,
          next: { revalidate: 600 },
        })
        if (!res.ok) return null
        return await res.text()
      } catch {
        return null
      }
    }),
  )

  const servers: Server[] = []
  const seen = new Set<string>()

  results.forEach((html) => {
    if (!html) return
    const match = html.match(/<iframe[^>]+src=["']([^"']+)["']/i)
    if (!match) return
    let url = match[1]
    if (url.startsWith("//")) url = `https:${url}`
    if (!/^https?:\/\//i.test(url)) return
    if (seen.has(url)) return
    seen.add(url)
    let host = ""
    try {
      host = new URL(url).hostname.replace(/^www\./, "")
    } catch {
      return
    }
    servers.push({ url, host, name: labelFor(host, servers.length) })
  })

  // Prefer the site's own ad-free player first.
  servers.sort((a, b) => {
    const score = (s: Server) => (s.host.includes("player.tokusatsuindo.com") ? 0 : 1)
    return score(a) - score(b)
  })

  return servers
}

// --- Direct stream resolution -------------------------------------------

function decodeBase64Url(input: string): string {
  const pad = input + "=".repeat((4 - (input.length % 4)) % 4)
  const normalized = pad.replace(/-/g, "+").replace(/_/g, "/")
  return Buffer.from(normalized, "base64").toString("utf8")
}

type PlayerPayload = {
  file_id?: string
  file_id_1?: string
  file_id_2?: string
  google_drive_url_1?: string
  google_drive_url_2?: string
  title?: string
}

// The site's player works in two hops: an outer `/x/?t=` page that embeds an
// inner `/p/?t=<jwt>` iframe. The first segment of that inner JWT is base64url
// JSON containing the Google Drive file ids. We follow that chain here.
async function extractPlayerPayload(playerUrl: string): Promise<PlayerPayload | null> {
  try {
    let html = ""
    let token = ""

    const url = new URL(playerUrl)
    if (url.pathname.includes("/p/")) {
      token = url.searchParams.get("t") ?? ""
    } else {
      const res = await fetch(playerUrl, {
        headers: { "User-Agent": UA, Referer: SOURCE_ORIGIN },
        next: { revalidate: 600 },
      })
      if (!res.ok) return null
      html = await res.text()
      const inner = html.match(/\/p\/\?t=([A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*)/)
      if (inner) token = inner[1]
    }

    if (!token) return null
    const payloadSegment = token.split(".")[0]
    const json = decodeBase64Url(payloadSegment)
    return JSON.parse(json) as PlayerPayload
  } catch {
    return null
  }
}

function driveFileIds(payload: PlayerPayload): string[] {
  const ids = [payload.file_id_1, payload.file_id_2, payload.file_id].filter(
    (v): v is string => typeof v === "string" && v.length > 0,
  )
  return Array.from(new Set(ids))
}

// Pull a Google Drive file id out of any URL that contains one
// (e.g. https://drive.google.com/file/d/<ID>/preview).
function driveIdFromUrl(url: string): string | null {
  const m = url.match(/drive\.google\.com\/file\/d\/([A-Za-z0-9_-]+)/)
  return m ? m[1] : null
}

// Resolves a post into a list of playable sources. Each source is either:
//  - a direct Google Drive stream (with qualities, played ad-free via our
//    /api/stream proxy), or
//  - an embeddable iframe fallback (the site's own player, a Drive preview, or
//    gdplayer) when we cannot resolve a direct stream.
// This guarantees that as long as the site has *any* working player, we never
// show the "video not available" state.
export async function fetchSources(postId: number): Promise<VideoSource[]> {
  const servers = await fetchServers(postId)
  if (servers.length === 0) return []

  const sources: VideoSource[] = []
  const seenFileIds = new Set<string>()

  for (const server of servers) {
    // Collect any Drive file ids this server exposes.
    let fileIds: string[] = []
    if (server.host.includes("player.tokusatsuindo.com")) {
      const payload = await extractPlayerPayload(server.url)
      if (payload) fileIds = driveFileIds(payload)
    } else {
      const direct = driveIdFromUrl(server.url)
      if (direct) fileIds = [direct]
    }

    if (fileIds.length > 0) {
      for (const fileId of fileIds) {
        if (seenFileIds.has(fileId)) continue
        seenFileIds.add(fileId)
        const streams = await resolveDriveStreams(fileId)
        sources.push({
          name: server.name,
          fileId,
          qualities: streams.map((s) => ({ itag: s.itag, label: s.label })),
          // Prefer the ad-free site player as the iframe fallback; otherwise
          // use the Drive preview for this exact file.
          embedUrl: server.host.includes("player.tokusatsuindo.com")
            ? server.url
            : `https://drive.google.com/file/d/${fileId}/preview`,
        })
      }
    } else {
      // No resolvable Drive id (e.g. gdplayer): keep it as an iframe-only
      // fallback so the episode still plays.
      sources.push({ name: server.name, fileId: "", qualities: [], embedUrl: server.url })
    }
  }

  // Sources with a direct (ad-free) stream come first so they are the default.
  sources.sort((a, b) => (b.qualities.length > 0 ? 1 : 0) - (a.qualities.length > 0 ? 1 : 0))

  return sources
}

export async function fetchFilm(id: number): Promise<Film | null> {
  const res = await fetch(
    `${REST}/posts/${id}?_embed=wp:featuredmedia,wp:term&_fields=id,slug,date,title,views,_links,_embedded`,
    { headers: { "User-Agent": UA }, next: { revalidate: 300 } },
  )
  if (!res.ok) return null
  const data = (await res.json()) as WpPost
  return mapPost(data)
}
