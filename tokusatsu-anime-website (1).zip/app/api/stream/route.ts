import type { NextRequest } from "next/server"
import { getStreamUrl, DRIVE_UA } from "@/lib/drive"

// Streams a Google Drive video through our own server.
//
// The browser hits /api/stream?fid=<fileId>&itag=<itag>. We resolve the file
// to a direct googlevideo MP4 URL (IP-locked to this server) and pipe the bytes
// back, forwarding Range headers so seeking works. This removes the Google
// login wall, the quota error, and any third-party ads entirely.

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const fid = searchParams.get("fid")
  const itagParam = searchParams.get("itag")

  if (!fid) {
    return new Response("Missing file id", { status: 400 })
  }

  const itag = itagParam ? Number(itagParam) : undefined
  const streamUrl = await getStreamUrl(fid, Number.isFinite(itag) ? itag : undefined)

  if (!streamUrl) {
    return new Response("Stream not available", { status: 404 })
  }

  const range = req.headers.get("range")
  const upstreamHeaders: Record<string, string> = {
    "User-Agent": DRIVE_UA,
    Referer: "https://drive.google.com/",
  }
  if (range) upstreamHeaders["Range"] = range

  const upstream = await fetch(streamUrl, {
    headers: upstreamHeaders,
    cache: "no-store",
  })

  if (!upstream.ok && upstream.status !== 206) {
    return new Response("Upstream error", { status: 502 })
  }

  const headers = new Headers()
  const passthrough = [
    "content-type",
    "content-length",
    "content-range",
    "accept-ranges",
    "cache-control",
    "expires",
    "last-modified",
  ]
  for (const key of passthrough) {
    const value = upstream.headers.get(key)
    if (value) headers.set(key, value)
  }
  if (!headers.has("content-type")) headers.set("content-type", "video/mp4")
  if (!headers.has("accept-ranges")) headers.set("accept-ranges", "bytes")

  return new Response(upstream.body, {
    status: upstream.status,
    headers,
  })
}
