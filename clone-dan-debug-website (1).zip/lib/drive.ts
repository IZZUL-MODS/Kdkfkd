// Resolves a Google Drive file into direct, ad-free, login-free MP4 stream URLs.
//
// Both "servers" on the source site ultimately embed a Google Drive `/preview`
// iframe. That iframe is what triggers the "login to your Google account" wall
// and the "error playing this video" message once a file hits Google's
// per-file viewer quota. Instead, we hit Drive's legacy `get_video_info`
// endpoint which returns transcoded progressive MP4 URLs (the `videoplayback`
// streams). Those URLs are locked to the requesting IP, so we proxy them
// through our own server (see app/api/stream/route.ts).

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

export type DriveStream = {
  itag: number
  // Human readable quality label, e.g. "720p".
  label: string
  // The resolved (IP-locked, time-limited) googlevideo URL. Never sent to the
  // browser — only used server-side by the stream proxy.
  url: string
}

// Why a file could not be resolved into a direct stream.
//  - "quota": Google's per-file viewer limit was hit (errorcode 150 — the
//    "sign in to your Google account / limit reached" wall). Only an
//    authenticated session can lift this.
//  - "unavailable": the file is private/removed or Drive returned no streams.
//  - null: resolution succeeded.
export type DriveUnavailableReason = "quota" | "unavailable" | null

export type DriveResolution = {
  streams: DriveStream[]
  reason: DriveUnavailableReason
}

type CacheEntry = {
  resolution: DriveResolution
  expires: number
}

// In-memory cache of resolved streams keyed by file id. The googlevideo URLs
// are time-limited, so we keep them only briefly. Failures are cached for a
// shorter window so a temporary hiccup doesn't stick.
const cache = new Map<string, CacheEntry>()
const CACHE_TTL_MS = 4 * 60 * 1000
const FAIL_TTL_MS = 45 * 1000

// Optional Google account cookie. When provided (via the GOOGLE_DRIVE_COOKIE
// env var), it is sent to get_video_info so quota-limited files that require a
// signed-in viewer ("the limit has been hit for viewers who aren't signed in")
// resolve normally. Without it we still serve every non-limited file ad-free.
function driveCookie(): string | null {
  const c = process.env.GOOGLE_DRIVE_COOKIE
  return c && c.trim().length > 0 ? c.trim() : null
}

// Public accessor for the stream proxy: when proxying an authenticated Google
// download URL (drive.usercontent.google.com), the cookie must be attached to
// every byte-range request, not just the initial resolution.
export function driveCookieHeader(): string | null {
  return driveCookie()
}

// Optional Google Drive API key (GOOGLE_DRIVE_API_KEY). Used to stream a file's
// bytes directly through the official Drive API v3 `files.get?alt=media`
// endpoint. That endpoint supports HTTP Range requests, has its own (high)
// project quota that is separate from the per-file "viewer limit", and never
// returns the "sign in / can't play this video" interstitial. It works for any
// file shared with "anyone with the link" (which the source's files are).
export function driveApiKey(): string | null {
  const k = process.env.GOOGLE_DRIVE_API_KEY
  return k && k.trim().length > 0 ? k.trim() : null
}

// Optional OAuth client id (GOOGLE_DRIVE_CLIENT_ID). Stored for browser-side
// Drive flows / Picker; not required for the server-side streaming fallback.
export function driveClientId(): string | null {
  const c = process.env.GOOGLE_DRIVE_CLIENT_ID
  return c && c.trim().length > 0 ? c.trim() : null
}

// Builds the official Drive API v3 media URL for a file id. Returns null when no
// API key is configured. Range-seekable; used by the stream proxy as a robust
// fallback when the source's own stream.php proxy can't serve a file.
export function driveApiMediaUrl(fileId: string): string | null {
  const key = driveApiKey()
  if (!key) return null
  const params = new URLSearchParams({
    alt: "media",
    key,
    supportsAllDrives: "true",
    acknowledgeAbuse: "true",
  })
  return `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?${params.toString()}`
}

function labelForHeight(height: number): string {
  if (height >= 2160) return "4K"
  if (height >= 1440) return "1440p"
  if (height >= 1080) return "1080p"
  if (height >= 720) return "720p"
  if (height >= 480) return "480p"
  if (height >= 360) return "360p"
  if (height >= 240) return "240p"
  return `${height}p`
}

// itag → fallback height when fmt_list doesn't carry a resolution.
const ITAG_HEIGHT: Record<number, number> = {
  37: 1080,
  46: 1080,
  22: 720,
  45: 720,
  59: 480,
  44: 480,
  35: 480,
  18: 360,
  43: 360,
  34: 360,
  36: 240,
  17: 144,
  5: 240,
}

// One attempt at hitting get_video_info. Returns the parsed params, or null on
// a network/transport error (worth retrying).
async function fetchVideoInfo(fileId: string): Promise<URLSearchParams | null> {
  const headers: Record<string, string> = {
    "User-Agent": UA,
    Referer: `https://drive.google.com/file/d/${fileId}/view`,
  }
  const cookie = driveCookie()
  if (cookie) headers["Cookie"] = cookie

  try {
    const res = await fetch(
      `https://drive.google.com/get_video_info?docid=${fileId}&el=detailpage&hl=en`,
      { headers, cache: "no-store" },
    )
    if (!res.ok) return null
    return new URLSearchParams(await res.text())
  } catch {
    return null
  }
}

// Resolves a Drive file into direct streams, distinguishing a true viewer-quota
// block (errorcode 150) from a transient/empty failure. Retries transient
// failures a couple of times before giving up.
export async function resolveDrive(fileId: string): Promise<DriveResolution> {
  const cached = cache.get(fileId)
  if (cached && cached.expires > Date.now()) {
    return cached.resolution
  }

  let params: URLSearchParams | null = null
  for (let attempt = 0; attempt < 3; attempt++) {
    params = await fetchVideoInfo(fileId)
    if (params) break
    await new Promise((r) => setTimeout(r, 300 * (attempt + 1)))
  }

  const fail = (reason: DriveUnavailableReason): DriveResolution => {
    const resolution = { streams: [], reason }
    cache.set(fileId, { resolution, expires: Date.now() + FAIL_TTL_MS })
    return resolution
  }

  if (!params) return fail("unavailable")

  if (params.get("status") !== "ok") {
    // errorcode 150 = "playback limit exceeded / sign in to continue".
    const code = params.get("errorcode")
    return fail(code === "150" ? "quota" : "unavailable")
  }

  // fmt_list maps itag -> resolution, e.g. "22/1280x720/...,18/640x360/...".
  const heightByItag = new Map<number, number>()
  const fmtList = params.get("fmt_list") ?? ""
  for (const entry of fmtList.split(",")) {
    const [itagStr, res2] = entry.split("/")
    const itag = Number(itagStr)
    const height = Number((res2 ?? "").split("x")[1])
    if (Number.isFinite(itag) && Number.isFinite(height)) {
      heightByItag.set(itag, height)
    }
  }

  // fmt_stream_map maps itag -> url, e.g. "22|https://...,18|https://...".
  const streamMap = params.get("fmt_stream_map") ?? ""
  const streams: DriveStream[] = []
  for (const entry of streamMap.split(",")) {
    const sep = entry.indexOf("|")
    if (sep === -1) continue
    const itag = Number(entry.slice(0, sep))
    const url = entry.slice(sep + 1)
    if (!Number.isFinite(itag) || !/^https?:\/\//.test(url)) continue
    const height = heightByItag.get(itag) ?? ITAG_HEIGHT[itag] ?? 0
    streams.push({ itag, label: labelForHeight(height), url })
  }

  // Highest quality first.
  streams.sort((a, b) => {
    const ha = heightByItag.get(a.itag) ?? ITAG_HEIGHT[a.itag] ?? 0
    const hb = heightByItag.get(b.itag) ?? ITAG_HEIGHT[b.itag] ?? 0
    return hb - ha
  })

  if (streams.length === 0) return fail("unavailable")

  const resolution: DriveResolution = { streams, reason: null }
  cache.set(fileId, { resolution, expires: Date.now() + CACHE_TTL_MS })
  return resolution
}

export async function resolveDriveStreams(fileId: string): Promise<DriveStream[]> {
  const { streams } = await resolveDrive(fileId)
  return streams
}

// Returns the resolved googlevideo URL for a specific file + itag (or the best
// available quality if no itag is given). Used by the stream proxy.
export async function getStreamUrl(fileId: string, itag?: number): Promise<string | null> {
  const streams = await resolveDriveStreams(fileId)
  if (streams.length === 0) return null
  if (itag != null) {
    const match = streams.find((s) => s.itag === itag)
    if (match) return match.url
  }
  return streams[0].url
}

// --- Authenticated HD download -------------------------------------------
//
// get_video_info only ever returns Google's progressive transcodes, which top
// out at 360p (itag 18) for most files. To play quota-limited files in their
// ORIGINAL HD quality through our ad-free proxy, we use Drive's authenticated
// direct-download endpoint instead. For large files Google serves a
// "virus scan" confirmation page first; we parse its form and follow it to the
// real, byte-range-seekable file. The resolved URL is locked to the cookie's
// session, so the stream proxy re-attaches the cookie on every Range request.

const DOWNLOAD_HOST = "drive.usercontent.google.com"

export type DriveDownload = {
  url: string | null
  reason: DriveUnavailableReason
}

const downloadCache = new Map<string, { url: string; expires: number }>()
const DL_TTL_MS = 5 * 60 * 1000

// Hostname of an authenticated Drive download URL (used by the stream proxy to
// decide whether to attach the cookie).
export function isDriveDownloadHost(hostname: string): boolean {
  return hostname === DOWNLOAD_HOST
}

export async function resolveDriveDownload(fileId: string): Promise<DriveDownload> {
  const cached = downloadCache.get(fileId)
  if (cached && cached.expires > Date.now()) {
    return { url: cached.url, reason: null }
  }

  const headers: Record<string, string> = { "User-Agent": UA }
  const cookie = driveCookie()
  if (cookie) headers["Cookie"] = cookie

  const base = `https://${DOWNLOAD_HOST}/download?id=${fileId}&export=download`

  let res: Response
  try {
    res = await fetch(base, { headers, cache: "no-store", redirect: "follow" })
  } catch {
    return { url: null, reason: "unavailable" }
  }

  const contentType = res.headers.get("content-type") ?? ""

  const cache = (url: string): DriveDownload => {
    downloadCache.set(fileId, { url, expires: Date.now() + DL_TTL_MS })
    return { url, reason: null }
  }

  // Small files stream straight away with no confirmation interstitial.
  if (!contentType.includes("text/html")) {
    return cache(base)
  }

  const html = await res.text()

  // The confirmation page is an HTML form with hidden inputs (id, export,
  // confirm, uuid, at). Parse them and rebuild the final download URL.
  const action =
    html.match(/action="([^"]+)"/)?.[1] ?? `https://${DOWNLOAD_HOST}/download`
  const fields: Record<string, string> = {}
  const inputRe = /name="([^"]+)"\s+value="([^"]*)"/g
  let m: RegExpExecArray | null
  while ((m = inputRe.exec(html))) {
    fields[m[1]] = m[2]
  }

  // No form + HTML body means a quota / sign-in / unavailable error page.
  if (!fields.confirm && !fields.id) {
    const quota = /quota|exceeded|too many|sign in|can.?t.*download/i.test(html)
    return { url: null, reason: quota ? "quota" : "unavailable" }
  }

  const params = new URLSearchParams()
  for (const [k, v] of Object.entries(fields)) params.set(k, v)
  if (!params.get("id")) params.set("id", fileId)
  if (!params.get("export")) params.set("export", "download")

  return cache(`${action}?${params.toString()}`)
}

export { UA as DRIVE_UA }
