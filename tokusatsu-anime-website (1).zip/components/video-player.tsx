"use client"

import { useMemo, useRef, useState } from "react"
import { Server, MonitorPlay, Settings2 } from "lucide-react"
import type { VideoSource } from "@/lib/tokusatsu"

function streamSrc(fileId: string, itag?: number): string {
  const params = new URLSearchParams({ fid: fileId })
  if (itag != null) params.set("itag", String(itag))
  return `/api/stream?${params.toString()}`
}

export function VideoPlayer({ sources }: { sources: VideoSource[] }) {
  const playable = useMemo(() => sources.filter((s) => s.qualities.length > 0), [sources])
  // First source that exposes an iframe URL, used only as a last resort after
  // every direct (ad-free) proxy stream has failed.
  const fallback = useMemo(() => sources.find((s) => s.embedUrl), [sources])

  const [activeSource, setActiveSource] = useState(0)
  const [activeQuality, setActiveQuality] = useState(0)
  // Set to true only once every direct stream has failed.
  const [useFallback, setUseFallback] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  if (playable.length === 0 && !fallback) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl border border-border bg-card text-center text-muted-foreground">
        <MonitorPlay className="h-10 w-10" />
        <p className="font-condensed text-2xl tracking-widest">VIDEO BELUM TERSEDIA</p>
        <p className="max-w-sm text-sm">Sumber sedang menyiapkan episode ini. Coba lagi nanti.</p>
      </div>
    )
  }

  // Direct streaming unavailable — use the Drive preview iframe as a last resort.
  if (playable.length === 0 || useFallback) {
    return (
      <div className="flex flex-col gap-4">
        <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-border bg-black shadow-2xl shadow-primary/20 ring-1 ring-primary/20">
          <iframe
            key={fallback?.embedUrl}
            src={fallback?.embedUrl}
            title="Video"
            className="h-full w-full"
            allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
            allowFullScreen
            referrerPolicy="no-referrer"
          />
        </div>
      </div>
    )
  }

  const source = playable[Math.min(activeSource, playable.length - 1)]
  const quality = source.qualities[Math.min(activeQuality, source.qualities.length - 1)]

  return (
    <div className="flex flex-col gap-4">
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-border bg-black shadow-2xl shadow-primary/20 ring-1 ring-primary/20">
        <video
          ref={videoRef}
          key={`${source.fileId}-${quality.itag}`}
          src={streamSrc(source.fileId, quality.itag)}
          className="h-full w-full bg-black"
          controls
          autoPlay
          playsInline
          controlsList="nodownload"
          onError={() => {
            // If this proxy stream can't play, first try the next ad-free
            // server. Only after exhausting all of them do we drop to the
            // Drive preview iframe as a last resort.
            if (activeSource < playable.length - 1) {
              setActiveSource(activeSource + 1)
              setActiveQuality(0)
            } else if (fallback) {
              setUseFallback(true)
            }
          }}
        />
      </div>

      <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
        {playable.length > 1 && (
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              <Server className="h-4 w-4" />
              Server:
            </span>
            {playable.map((s, i) => (
              <button
                key={s.fileId}
                type="button"
                onClick={() => {
                  setActiveSource(i)
                  setActiveQuality(0)
                }}
                className={`rounded-full px-4 py-1.5 text-xs font-medium transition-colors ${
                  i === activeSource
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-primary/20"
                }`}
              >
                {s.name}
              </button>
            ))}
          </div>
        )}

        {source.qualities.length > 1 && (
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              <Settings2 className="h-4 w-4" />
              Kualitas:
            </span>
            {source.qualities.map((q, i) => (
              <button
                key={q.itag}
                type="button"
                onClick={() => setActiveQuality(i)}
                className={`rounded-full px-4 py-1.5 text-xs font-medium transition-colors ${
                  i === activeQuality
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-primary/20"
                }`}
              >
                {q.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
