import Link from "next/link"
import { notFound } from "next/navigation"
import type { Metadata } from "next"
import { ArrowLeft, Eye, Calendar, ShieldCheck } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { SiteFooter } from "@/components/site-footer"
import { VideoPlayer } from "@/components/video-player"
import { ScrollReveal } from "@/components/scroll-reveal"
import { fetchFilm, fetchSources } from "@/lib/tokusatsu"

export const revalidate = 600

type Params = { params: Promise<{ id: string }> }

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { id } = await params
  const film = await fetchFilm(Number(id))
  if (!film) return { title: "Film tidak ditemukan — Tokusatsu" }
  return {
    title: `${film.title} — Tokusatsu`,
    description: `Nonton ${film.title} sub Indonesia tanpa iklan di Tokusatsu by izzul.`,
  }
}

export default async function WatchPage({ params }: Params) {
  const { id } = await params
  const filmId = Number(id)
  if (!Number.isFinite(filmId)) notFound()

  const [film, sources] = await Promise.all([fetchFilm(filmId), fetchSources(filmId)])
  if (!film) notFound()

  const date = new Date(film.date).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  })

  return (
    <>
      <div className="aura" aria-hidden />
      <Navbar />
      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
        <Link
          href="/"
          className="mb-6 inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          <ArrowLeft className="h-4 w-4" />
          Kembali ke beranda
        </Link>

        <ScrollReveal>
          <VideoPlayer sources={sources} />
        </ScrollReveal>

        <ScrollReveal delay={100} className="mt-8">
          <h1 className="text-balance font-display text-2xl font-bold leading-tight sm:text-3xl">
            {film.title}
          </h1>

          <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              {date}
            </span>
            {film.views != null && (
              <span className="inline-flex items-center gap-1.5">
                <Eye className="h-4 w-4" />
                {film.views.toLocaleString("id-ID")} tayangan
              </span>
            )}
            <span className="inline-flex items-center gap-1.5 text-primary">
              <ShieldCheck className="h-4 w-4" />
              Tanpa iklan
            </span>
          </div>

          {film.genres.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {film.genres.map((g) => (
                <span
                  key={g}
                  className="rounded-full bg-secondary px-3 py-1 text-xs font-medium uppercase tracking-wide text-secondary-foreground"
                >
                  {g}
                </span>
              ))}
            </div>
          )}
        </ScrollReveal>
      </main>
      <SiteFooter />
    </>
  )
}
