"use client"

import useSWR from "swr"
import { useEffect, useMemo, useState } from "react"
import { Search, Loader2, X, ArrowLeft, ArrowRight, Frown } from "lucide-react"
import type { Category, Film } from "@/lib/tokusatsu"
import { FilmCard } from "./film-card"
import { ScrollReveal } from "./scroll-reveal"

type FilmsResponse = { films: Film[]; totalPages: number }

const fetcher = (url: string) => fetch(url).then((r) => r.json())

function useDebounced<T>(value: T, ms: number) {
  const [debounced, setDebounced] = useState(value)
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), ms)
    return () => clearTimeout(id)
  }, [value, ms])
  return debounced
}

export function FilmBrowser({
  initial,
  categories,
}: {
  initial: FilmsResponse
  categories: Category[]
}) {
  const [query, setQuery] = useState("")
  const [category, setCategory] = useState<number | null>(null)
  const [page, setPage] = useState(1)
  const debouncedQuery = useDebounced(query, 450)

  // Reset to page 1 whenever the search or filter changes.
  useEffect(() => {
    setPage(1)
  }, [debouncedQuery, category])

  const params = useMemo(() => {
    const p = new URLSearchParams()
    if (debouncedQuery) p.set("search", debouncedQuery)
    if (category) p.set("category", String(category))
    p.set("page", String(page))
    return p.toString()
  }, [debouncedQuery, category, page])

  const isDefaultView = !debouncedQuery && !category && page === 1

  const { data, isLoading } = useSWR<FilmsResponse>(
    `/api/films?${params}`,
    fetcher,
    {
      fallbackData: isDefaultView ? initial : undefined,
      keepPreviousData: true,
      revalidateOnFocus: false,
    },
  )

  const films = data?.films ?? []
  const totalPages = data?.totalPages ?? 1

  return (
    <section id="jelajah" className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <ScrollReveal className="mb-8 text-center">
        <h2 className="font-display text-3xl font-bold uppercase tracking-tight sm:text-4xl">
          <span className="fx-gradient">Jelajah Film</span>
        </h2>
        <p className="mx-auto mt-3 max-w-lg text-sm text-muted-foreground">
          Ketik judul tokusatsu apa pun untuk mencarinya secara langsung.
        </p>
      </ScrollReveal>

      {/* Search bar */}
      <div className="mx-auto mb-6 flex max-w-xl items-center gap-2 rounded-full border border-border bg-card px-4 py-2 shadow-sm focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/30">
        <Search className="h-5 w-5 shrink-0 text-muted-foreground" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Cari: Kamen Rider, Ultraman, Gavan..."
          aria-label="Cari film tokusatsu"
          className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery("")}
            aria-label="Hapus pencarian"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
        {isLoading && <Loader2 className="h-4 w-4 animate-spin text-primary" />}
      </div>

      {/* Category chips */}
      <div className="mb-10 flex flex-wrap items-center justify-center gap-2">
        <button
          type="button"
          onClick={() => setCategory(null)}
          className={`rounded-full px-4 py-1.5 text-xs font-medium uppercase tracking-wide transition-colors ${
            category === null
              ? "bg-primary text-primary-foreground"
              : "bg-secondary text-secondary-foreground hover:bg-primary/20"
          }`}
        >
          Semua
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setCategory(c.id)}
            className={`rounded-full px-4 py-1.5 text-xs font-medium uppercase tracking-wide transition-colors ${
              category === c.id
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground hover:bg-primary/20"
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>

      {/* Results */}
      {films.length === 0 && !isLoading ? (
        <div className="flex flex-col items-center gap-3 py-20 text-center text-muted-foreground">
          <Frown className="h-10 w-10" />
          <p className="font-condensed text-2xl tracking-widest">TIDAK ADA HASIL</p>
          <p className="text-sm">Coba kata kunci lain ya.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {films.map((film, i) => (
            <ScrollReveal key={film.id} delay={Math.min(i, 11) * 45}>
              <FilmCard film={film} />
            </ScrollReveal>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && films.length > 0 && (
        <div className="mt-12 flex items-center justify-center gap-4">
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => {
              setPage((p) => Math.max(1, p - 1))
              document.getElementById("jelajah")?.scrollIntoView({ behavior: "smooth" })
            }}
            className="inline-flex items-center gap-1 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium transition-colors hover:border-primary disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ArrowLeft className="h-4 w-4" />
            Sebelumnya
          </button>
          <span className="font-condensed text-lg tracking-widest text-muted-foreground">
            {page} / {totalPages}
          </span>
          <button
            type="button"
            disabled={page >= totalPages}
            onClick={() => {
              setPage((p) => Math.min(totalPages, p + 1))
              document.getElementById("jelajah")?.scrollIntoView({ behavior: "smooth" })
            }}
            className="inline-flex items-center gap-1 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium transition-colors hover:border-primary disabled:cursor-not-allowed disabled:opacity-40"
          >
            Berikutnya
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      )}
    </section>
  )
}
