"use client"

import { useState } from "react"
import { Server, MonitorPlay } from "lucide-react"
import type { Server as VideoServer } from "@/lib/tokusatsu"

export function VideoPlayer({ servers }: { servers: VideoServer[] }) {
  const [active, setActive] = useState(0)

  if (servers.length === 0) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl border border-border bg-card text-center text-muted-foreground">
        <MonitorPlay className="h-10 w-10" />
        <p className="font-condensed text-2xl tracking-widest">VIDEO BELUM TERSEDIA</p>
        <p className="max-w-sm text-sm">
          Sumber sedang menyiapkan episode ini. Coba lagi nanti.
        </p>
      </div>
    )
  }

  const current = servers[Math.min(active, servers.length - 1)]

  return (
    <div className="flex flex-col gap-4">
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-border bg-black shadow-2xl shadow-primary/20 ring-1 ring-primary/20">
        <iframe
          key={current.url}
          src={current.url}
          title={current.name}
          className="h-full w-full"
          allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
          allowFullScreen
          referrerPolicy="no-referrer"
        />
      </div>

      {servers.length > 1 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <Server className="h-4 w-4" />
            Pilih server:
          </span>
          {servers.map((s, i) => (
            <button
              key={s.url}
              type="button"
              onClick={() => setActive(i)}
              className={`rounded-full px-4 py-1.5 text-xs font-medium transition-colors ${
                i === active
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-primary/20"
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
