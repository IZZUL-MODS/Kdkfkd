import { NextResponse } from "next/server"
import { fetchServers } from "@/lib/tokusatsu"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = Number(searchParams.get("id"))
  if (!Number.isFinite(id) || id <= 0) {
    return NextResponse.json({ error: "invalid id" }, { status: 400 })
  }
  const servers = await fetchServers(id)
  return NextResponse.json(
    { servers },
    {
      headers: {
        "Cache-Control": "public, s-maxage=600, stale-while-revalidate=1200",
      },
    },
  )
}
